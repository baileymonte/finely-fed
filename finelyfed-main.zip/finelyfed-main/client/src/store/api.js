import Butter from 'buttercms'

// const token = '6777e09ea5f7a6ec12bef4431c213d8d53d988f6'
const token = 'fdcc36c7e4a19585589858fdbdd0cfc87a7ebe9e'


export const butter = Butter(token)
